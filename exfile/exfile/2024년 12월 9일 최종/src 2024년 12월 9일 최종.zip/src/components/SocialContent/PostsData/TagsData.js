export const tagsData = [
    {
        img: "https://th.bing.com/th/id/OIP.GzS2D-ORihAk335UhUdKmAHaJr?w=121&h=180&c=7&r=0&o=5&pid=1.7/",
        userImg: "https://fakeimg.pl/26x26/",
        userId: "태그1",
        likes: "♡2",
        tags: "#추천상품 #태그상품"
    },
    {
        img: "https://th.bing.com/th/id/OIP.BEMPwjniPmrMseAtLSdRSQHaFK?w=252&h=180&c=7&r=0&o=5&pid=1.7",
        userImg: "https://fakeimg.pl/26x26/",
        userId: "태그2",
        likes: "♡5",
        tags: "#여름상품 #핫딜"
    },
    {
        img: "https://fakeimg.pl/262x262/",
        userImg: "https://fakeimg.pl/26x26/",
        userId: "태그2",
        likes: "♡5",
        tags: "#여름상품 #핫딜"
    },
    {
        img: "https://fakeimg.pl/262x262/",
        userImg: "https://fakeimg.pl/26x26/",
        userId: "태그2",
        likes: "♡5",
        tags: "#여름상품 #핫딜"
    },
    {
        img: "https://fakeimg.pl/262x262/",
        userImg: "https://fakeimg.pl/26x26/",
        userId: "태그2",
        likes: "♡5",
        tags: "#여름상품 #핫딜"
    },
    {
        img: "https://fakeimg.pl/262x262/",
        userImg: "https://fakeimg.pl/26x26/",
        userId: "태그2",
        likes: "♡5",
        tags: "#여름상품 #핫딜"
    }
];