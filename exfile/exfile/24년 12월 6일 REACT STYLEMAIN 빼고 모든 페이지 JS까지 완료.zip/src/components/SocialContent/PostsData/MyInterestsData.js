export const myInterestsData = [
    {
        img: "https://th.bing.com/th/id/OIP.GzS2D-ORihAk335UhUdKmAHaJr?w=121&h=180&c=7&r=0&o=5&pid=1.7/",
        userId: "아이디1",
        MyInterests: "1"
    },
    {
        img: "https://th.bing.com/th/id/OIP.BEMPwjniPmrMseAtLSdRSQHaFK?w=252&h=180&c=7&r=0&o=5&pid=1.7",
        userId: "아이디2",
        MyInterests: "2"
    },
    {
        img: "https://th.bing.com/th/id/OIP.Kc5yq9pZKilNI9rwM2pEBwHaJ4?w=163&h=217&c=7&r=0&o=5&pid=1.7",
        userId: "아이디3",
        MyInterests: "3"
    },
    {
        img: "https://th.bing.com/th/id/OIP.IinX4NIoAVnCyoqykd5TzAHaEK?w=282&h=180&c=7&r=0&o=5&pid=1.7",
        userId: "아이디4",
        MyInterests: "4"
    },
    {
        img: "https://th.bing.com/th/id/OIF.xDLUlCK6SE8IqF5sefLhmA?w=193&h=192&c=7&r=0&o=5&dpr=1.3&pid=1.7",
        userId: "아이디5",
        MyInterests: "5"
    },
    {
        img: "https://th.bing.com/th/id/OIF.P0hQa8b1Q3HoFny5FOzEQg?w=187&h=187&c=7&r=0&o=5&dpr=1.3&pid=1.7",
        userId: "아이디6",
        MyInterests: "6"
    },
    {
        img: "https://th.bing.com/th/id/OIP.a6YaLbuJNlNMg9FQviDs1AHaEJ?w=317&h=180&c=7&r=0&o=5&dpr=1.3&pid=1.7",
        userId: "아이디7",
        MyInterests: "7"
    },
    {
        img: "https://th.bing.com/th/id/OIP.0YY-jxcsgWdB_6K5RK0NCQHaFS?w=249&h=180&c=7&r=0&o=5&dpr=1.3&pid=1.7",
        userId: "아이디7",
        MyInterests: "7"
    },
    {
        img: "https://th.bing.com/th/id/OIP.5iKGkKRY89Hl-wL4fQzGxQHaHa?w=181&h=182&c=7&r=0&o=5&dpr=1.3&pid=1.7",
        userId: "아이디7",
        MyInterests: "7"
    },
    {
        img: "https://th.bing.com/th/id/OIP.Y3he1vKLOAYAQHcGYzWwZAHaHa?w=194&h=194&c=7&r=0&o=5&dpr=1.3&pid=1.7",
        userId: "아이디7",
        MyInterests: "7"
    },
    {
        img: "https://th.bing.com/th/id/OIP.7b1X-IS56vf8ubcVgx_HbQHaE8?w=194&h=129&c=7&r=0&o=5&dpr=1.3&pid=1.7",
        userId: "아이디7",
        MyInterests: "7"
    },
    {
        img: "https://th.bing.com/th/id/OIP.qWpCr9rUWJforD_wPUIIvAHaEK?w=194&h=109&c=7&r=0&o=5&dpr=1.3&pid=1.7",
        userId: "아이디7",
        MyInterests: "7"
    }
];