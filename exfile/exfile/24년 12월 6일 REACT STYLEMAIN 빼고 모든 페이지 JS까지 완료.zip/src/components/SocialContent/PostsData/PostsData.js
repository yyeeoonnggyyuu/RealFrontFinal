export  const postsData = [
    { 
        id:'1',
        img: "https://th.bing.com/th/id/OIP.xJkEtVQbleAWihNLs5EQtgHaIx?w=140&h=180&c=7&r=0&o=5&pid=1.7",
        userImg: "https://fakeimg.pl/26x26/",
        userId: "아이디1",
        likes: "♡4",
        tags: "#겨울코디 #아우터추천"
    },
    { 
        id:'2',
        img: "https://th.bing.com/th/id/OIP.Kc5yq9pZKilNI9rwM2pEBwHaJ4?w=163&h=217&c=7&r=0&o=5&pid=1.7",
        userImg: "https://fakeimg.pl/26x26/",
        userId: "아이디2",
        likes: "♡7",
        tags: "#봄패션 #사이즈팁"
    },
    { 
        id:'3',
        img: "https://fakeimg.pl/262x262/",
        userImg: "https://fakeimg.pl/26x26/",
        userId: "아이디2",
        likes: "♡7",
        tags: "#봄패션 #사이즈팁"
    },
    { 
        id:'4',
        img: "https://fakeimg.pl/262x262/",
        userImg: "https://fakeimg.pl/26x26/",
        userId: "아이디2",
        likes: "♡7",
        tags: "#봄패션 #사이즈팁"
    },
    { 
        id:'5',
        img: "https://fakeimg.pl/262x262/",
        userImg: "https://fakeimg.pl/26x26/",
        userId: "아이디2",
        likes: "♡7",
        tags: "#봄패션 #사이즈팁"
    }
];